/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CdkDirective } from './cdk.directive';

describe('Directive: Cdk', () => {
  it('should create an instance', () => {
    const directive = new CdkDirective();
    expect(directive).toBeTruthy();
  });
});
