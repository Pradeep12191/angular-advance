export enum KeyboardAnimationState {
  Void = 'void',
  Visible = 'visible',
  Hidden = 'hidden'
}
