import { Component } from "@angular/core";

@Component({
    template: '<div>portal</div>'
})
export class SampleComponent {

}