export default class RepeatContext {

    constructor(
        private $implicit,
        private index,
        private odd,
        private even,
        private last,
        private first
    ) {

    }
}
