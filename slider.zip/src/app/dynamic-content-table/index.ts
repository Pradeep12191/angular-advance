export * from './models/ClickInfo';
export const MOBILE_HDR_PREFIX = '-mobile-header';
