export interface ClickInfo {
    rowInfo: any;
    cellInfo: any;
}
