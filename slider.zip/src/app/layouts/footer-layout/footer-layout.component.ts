import { Component } from '@angular/core';

@Component({
    templateUrl: './footer-layout.component.html'
})
export class FooterLayoutComponent {

}
