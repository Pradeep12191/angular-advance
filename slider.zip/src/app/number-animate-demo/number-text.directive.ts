import { Directive } from '@angular/core';

@Directive({
    // tslint:disable-next-line:directive-selector
    selector: '[numberText]'
})
export class NumberTextDirective {

}
