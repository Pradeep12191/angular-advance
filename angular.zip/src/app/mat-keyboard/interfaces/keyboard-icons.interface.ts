export interface IKeyboardIcons {
  [key: string]: string;
}
