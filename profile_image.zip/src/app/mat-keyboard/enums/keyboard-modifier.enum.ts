// this enum index has to be number based because it is used
// to access the keyboard configs alternative key assignment
export enum KeyboardModifier {
  None,
  Shift,
  Alt,
  ShiftAlt
}
