

export interface Control {
    ty: string;
    ctrlName: string;
    defaultValue: string;
}
