import { InjectionToken } from '@angular/core';

export const CARD_DATA = new InjectionToken<any>('CARD_DATA');
