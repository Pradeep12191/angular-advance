import { Component, OnInit, ContentChildren, QueryList, AfterContentInit, ElementRef } from '@angular/core';
import { BgContentDirective } from './bg-content.directive';
import { BgContentAnimationConfig } from './bg-content-animation/bg-content-animation.config';

@Component({
  selector: 'app-content-animation-demo',
  templateUrl: './content-animation-demo.component.html',
  styleUrls: ['./content-animation-demo.component.css']
})
export class ContentAnimationDemoComponent implements OnInit {

  public bgContentAnimationConfig: BgContentAnimationConfig;
  public card1Data;
  public card2Data;

  constructor(

  ) { }

  ngOnInit() {
    this.bgContentAnimationConfig = {
      animation: 'slideLeft',
      animationDuration: '5s',
      offAnimation: true
    };
    this.card1Data = {
      cardContent: `The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog from Japan.
      A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally
      bred for hunting.`,
      cardTitle: 'Shibha Inu',
      cardSubtitle: 'Dog bread',
      cardAvatar: 'https://material.angular.io/assets/img/examples/shiba1.jpg'
    };
    this.card2Data = {
      cardContent: `American Ninja Warrior (sometimes abbreviated as ANW) is an American sports entertainment competition, 
      which is a spin-off of the Japanese television series Sasuke.`,
      cardTitle: 'Ninja',
      cardSubtitle: 'Warrior',
      cardAvatar: 'https://upload.wikimedia.org/wikipedia/en/d/df/American_Ninja_Warrior_Logo.jpg'
    };
  }
}
