import {
  Component, OnInit, AfterContentInit, ContentChildren,
  QueryList, ViewContainerRef, TemplateRef, Renderer2, ViewChild, Input, OnDestroy
} from '@angular/core';
import { BgContentDirective } from '../bg-content.directive';
import { AnimationBuilder, AnimationMetadata, style, animate, AnimationPlayer } from '@angular/animations';
import { animations } from '../../animations/bg-animations';
import { BgContentAnimationConfig } from './bg-content-animation.config';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'bg-content-animation',
  templateUrl: './bg-content-animation.component.html',
  styleUrls: ['./bg-content-animation.component.scss']
})
export class BgContentAnimationComponent implements OnInit, AfterContentInit, OnDestroy {

  @Input() config: BgContentAnimationConfig;

  @ContentChildren(BgContentDirective, { read: TemplateRef }) slides: QueryList<TemplateRef<BgContentDirective>>;
  @ViewChild('slider', { read: ViewContainerRef }) sliderContainer: ViewContainerRef;
  public activeSlideIndex = 0;
  public slidesArray = [];
  private _enterAnimationPlayer: AnimationPlayer;
  private _leaveAnimationPlayer: AnimationPlayer;
  private _activeSlideEl;
  private _hasDestoryed;
  private _manualtrigger = true;
  private _hasAnimationFinished = true;
  constructor(
    private vc: ViewContainerRef,
    private animationBuilder: AnimationBuilder,
    private render: Renderer2
  ) { }

  ngOnInit() {
  }

  get animationType() {
    return this.config.animation;
  }

  set animationType(animation) {
    this.config.animation = animation;
  }

  get animationDuration() {
    return this.config.animationDuration;
  }

  get offAnimation() {
    return this.config.offAnimation;
  }

  ngAfterContentInit() {
    this.slidesArray = this.slides.toArray();

    if (this.offAnimation) {
      const slideRef = this.sliderContainer.createEmbeddedView(this.slidesArray[0]);
      return this._activeSlideEl = slideRef.rootNodes[0];
    }
    this._start();
    this._enterAnimation();
    // this.sliderContainer.createEmbeddedView(this._slidesArray[0]);
    // this.sliderContainer.createEmbeddedView(this._slidesArray[1]);
  }

  ngOnDestroy() {
    this._hasDestoryed = true;
    if (this._enterAnimationPlayer) { this._enterAnimationPlayer.destroy(); }
    if (this._leaveAnimationPlayer) { this._leaveAnimationPlayer.destroy(); }
    if (this.sliderContainer) { this.sliderContainer.clear(); }
  }

  public gotToPrevious() {
    if (this._hasAnimationFinished) {
      if (this.animationType.startsWith('slide')) {
        this.animationType = 'slideLeft';
      }
      this._leaveAnimation();
      this._previous();
      this._enterAnimation();
      this._hasAnimationFinished = false;
    }

  }

  public goToNext() {
    if (this._hasAnimationFinished) {
      if (this.animationType.startsWith('slide')) {
        this.animationType = 'slideRight';
      }
      this._leaveAnimation();
      this._next();
      this._enterAnimation();
      this._hasAnimationFinished = false;
    }
  }

  public goTo(slideIndex) {

  }

  private _createAnimation(element, animationMeta: AnimationMetadata | AnimationMetadata[]) {
    const factory = this.animationBuilder.build(animationMeta);
    const player = factory.create(element);
    return player;
  }

  private _enterAnimation() {
    if (this._hasDestoryed) {
      return;
    }
    if (this._enterAnimationPlayer) {
      this._enterAnimationPlayer.destroy();
    }
    this._enterAnimationPlayer = this._createAnimation(this._activeSlideEl,
      animations[this.animationType](this.animationDuration).enter
    );

    if (!this._manualtrigger) {
      this._enterAnimationPlayer.onDone(() => {
        // setTimeout - wait between next image
        setTimeout(() => {
          this._leaveAnimation();
          this._next();
          this._enterAnimation();
        }, 2000);
      });
    } else {
      this._enterAnimationPlayer.onDone(() => {
        this._hasAnimationFinished = true;
      });
    }


    this._enterAnimationPlayer.play();
  }

  private _leaveAnimation() {
    if (this._hasDestoryed) {
      return;
    }
    if (this._leaveAnimationPlayer) {
      this._leaveAnimationPlayer.destroy();
    }
    this._leaveAnimationPlayer = this._createAnimation(this._activeSlideEl,
      animations[this.animationType](this.animationDuration).leave
    );
    this._leaveAnimationPlayer.onDone(() => {
      this.sliderContainer.remove(0);
    });
    this._leaveAnimationPlayer.play();
  }

  private _next() {
    if (this.activeSlideIndex === (this.slidesArray.length - 1)) {
      this.activeSlideIndex = 0;
    } else {
      this.activeSlideIndex++;
    }
    this._createSlide();
  }

  private _previous() {
    if (this.activeSlideIndex === 0) {
      this.activeSlideIndex = this.slides.length - 1;
    } else {
      this.activeSlideIndex--;
    }
    this._createSlide();
  }

  private _start() {
    this.activeSlideIndex = 0;
    this._createSlide();
  }

  private _createSlide() {
    const activeSlide = this.slidesArray[this.activeSlideIndex];
    const slideRef = this.sliderContainer.createEmbeddedView(activeSlide);
    this._activeSlideEl = slideRef.rootNodes[0];
  }

}
