export interface BgContentAnimationConfig {
    animation: 'fade' | 'slideRight' | 'slideLeft';
    animationDuration: string | number;
    offAnimation: boolean;
}
