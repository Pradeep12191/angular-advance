import { IKeyboardLayout } from './keyboard-layout.interface';

export interface IKeyboardLayouts {
  [layout: string]: IKeyboardLayout;
}
