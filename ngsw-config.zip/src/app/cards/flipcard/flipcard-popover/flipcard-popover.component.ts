import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flipcard-popover',
  templateUrl: './flipcard-popover.component.html',
  styleUrls: ['./flipcard-popover.component.css']
})
export class FlipcardPopoverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
