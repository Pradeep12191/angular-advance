import { Component, OnInit } from '@angular/core';
import { IndexedDbService } from './indexedDb.service';

@Component({
  selector: 'app-idb-demo',
  templateUrl: './idb-demo.component.html',
  styleUrls: ['./idb-demo.component.css']
})
export class IdbDemoComponent implements OnInit {
  localReadData: any;
rData: any;
posts: any;
  constructor(
    private idb: IndexedDbService
  ) { }

  async ngOnInit() {
       await this.idb.openDb('posts-store', 3, 'posts', 'id');
  }

  async writeData() {
    await this.idb.wtireData('posts', { name: 'pradeep', id: '1001' });
    await this.idb.wtireData('books', { name: 'book', id: '1001' });
    this.posts = {
      name: 'dhanraj',
      id: '1002'
    };
    localStorage.setItem('posts', JSON.stringify(this.posts));
  }

  async writeMoreData() {
    await this.idb.wtireData('posts', { name: 'dhanraj', id: '1002' });
    await this.idb.wtireData('books', { name: 'book', id: '1002' });
  }
  async readAllData() {
    const data = await this.idb.readAllData('posts');
    console.log(data);
  }

  // adding another data with same 'id' wont add new data as we mentioned 'id' as keyPath,
  // instead it will update the data with same 'id'
  async changeData() {
    await this.idb.wtireData('posts', { name: 'dhanraj-changed', id: '1002' });

  }

  async readData() {
    const data = await this.idb.readData('posts', '1001');
    console.log(JSON.stringify(data));
    this.rData = JSON.stringify(data);
  const lData = localStorage.getItem('posts');
  console.log(lData);
  this.localReadData = JSON.stringify(lData);
  }

  async clearStore() {
    await this.idb.clearStore('posts');
  }

  async dropDb() {
    await this.idb.dropDb('posts-store');
  }
  async clearSingleItem() {
    this.idb.clearItemInStore('posts', '1001');
  }
}
