import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-profile-progress-demo',
  templateUrl: './profile-progress-demo.component.html',
  styleUrls: ['./profile-progress-demo.component.css']
})
export class ProfileProgressDemoComponent implements OnInit {


  public progress = 0;
  public svgHeight = 170;
  public svgWidth = 170;
  public fillCircleRadius = 80;
  public pathCircleRadius = 73;
  public imageCircleRadius = 73;
  public fillStrokeWidth = 10;
  public pathStrokeWidth = 10;
  public dashArray = null;
  public dashOffset = null;

  constructor() { }

  ngOnInit() {
    this.dashArray = this._calcProgress(0);
    this.dashOffset = this._calcProgress(0);
    setTimeout(() => {
      this.dashOffset = this._calcProgress(25);
    }, 2000);
  }

  private _calcProgress(per?) {
    // circumfrence of the circle ( 2 * PI * r)
    const circumference = 2 * Math.PI * this.fillCircleRadius;
    if (!per) {
      return circumference;
    }
    return circumference * (1 - (per / 100));
  }

  

}
