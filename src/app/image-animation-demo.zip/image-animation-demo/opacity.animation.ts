import { trigger, transition, style, animate } from '@angular/animations';

export const imageState = trigger('imageState', [
    transition(':enter', [
        style({opacity: 0}),
        animate('3s')
    ]),
    transition(':leave', [
        animate('3s', style({opacity: 0}))
    ])
]);
