import { Component, OnInit } from '@angular/core';
import { AnimationEvent } from '@angular/animations';
import { imageState } from './opacity.animation';

@Component({
  selector: 'app-image-animation-demo',
  templateUrl: './image-animation-demo.component.html',
  styleUrls: ['./image-animation-demo.component.css'],
  animations: [imageState]
})
export class ImageAnimationDemoComponent implements OnInit {
  images = [
    { path: '/assets/images/banner-1.png' },
    { path: '/assets/images/9a_Angular-JS-development.jpg' },
    { path: '/assets/images/ninja-1533330173110.jpg' },
    { path: '/assets/images/react.736da783.png' }
  ];
  displayedImages = [];
  displayedImagesIndex = 0;
  constructor() { }

  ngOnInit() {
    this.displayedImages.push(this.images[this.displayedImagesIndex]);
    this.displayedImagesIndex++;
  }


  onImageAnimation(event: AnimationEvent) {
    console.log(event.fromState);
    if (event.fromState !== 'void' || this.images.length <= 1) {
      return;
    }
    this.displayedImages.pop();
    this.displayedImages.push(this.images[this.displayedImagesIndex]);
    if (this.displayedImagesIndex === (this.images.length - 1)) {
      this.displayedImagesIndex = 0;
    } else {
      this.displayedImagesIndex++;
    }
  }
}
