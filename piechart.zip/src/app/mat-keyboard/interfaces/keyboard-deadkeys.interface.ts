export interface IKeyboardDeadkeys {
  [deadkey: string]: {
    [target: string]: string;
  };
}
