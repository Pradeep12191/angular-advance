import { Component, OnInit } from '@angular/core';

const PIE_DATA = [
  {
    percentage: 0.45,
    label: 'Thing 1'
  },
  {
    percentage: 0.21,
    label: 'Thing Two'
  },
  {
    percentage: 0.11,
    label: 'Another Thing'
  },
  {
    percentage: 0.23,
    label: 'Pineapple'
  }
];

@Component({
  selector: 'app-raw-piechart',
  templateUrl: './raw-piechart.component.html',
  styleUrls: ['./raw-piechart.component.css']
})
export class RawPiechartComponent implements OnInit {

  public pieData;
  area = 200;
  sectorSide = 0;
  colors = [
    '#61C0BF', '#DA507A', '#BB3D49', '#DB4547'
  ];
  sectors = [];
  constructor() { }

  ngOnInit() {
    this.pieData = PIE_DATA;
    this.sectorSide = this.area / 2;
    console.log(this.createSectors());
    setTimeout(() => {
      this.sectors = this.createSectors();
    }, 1000)
    
  }

  createSectors() {
    const l = this.area / 2;
    let a = 0; // Angle
    let aRad = 0; // Angle in Rad
    let z = 0; // Size z
    let x = 0; // Side x
    let y = 0; // Side y
    let X = 0; // SVG X coordinate
    let Y = 0; // SVG Y coordinate
    let R = 0; // Rotation
    let aCalc = 0;
    let arcSweep = 0;
    const sectors = [];

    this.pieData.map((item, key) => {

      a = 360 * item.percentage;
      aCalc = (a > 180) ? 360 - a : a;
      aRad = aCalc * Math.PI / 180;
      z = Math.sqrt(2 * l * l - (2 * l * l * Math.cos(aRad)));
      if (aCalc <= 90) {
        x = l * Math.sin(aRad);
      } else {
        x = l * Math.sin((180 - aCalc) * Math.PI / 180);
      }

      y = Math.sqrt(z * z - x * x);
      Y = y;

      if (a <= 180) {
        X = l + x;
        arcSweep = 0;
      } else {
        X = l - x;
        arcSweep = 1;
      }

      sectors.push({
        percentage: item.percentage,
        label: item.label,
        color: this.colors[key],
        arcSweep: arcSweep,
        L: l,
        X: X,
        Y: Y,
        R: R
      });

      R = R + a;
    });
    return sectors;
  }
}
