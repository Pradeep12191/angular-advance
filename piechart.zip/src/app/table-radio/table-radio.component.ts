import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort } from '@angular/material';

const DATA = [
    { isSelected: false, period: 'April - June 2018', spends: '31700', cashback: '3170' },
    { isSelected: true, period: 'January - March 2018', spends: '31700', cashback: '3172' }
];

@Component({
    templateUrl: './table-radio.component.html',
    styleUrls: ['./table-radio.component.scss']
})
export class TableRadioComponent implements OnInit {
    dataSource = new MatTableDataSource(DATA);
    displayedColumns = ['isSelected', 'period', 'spends', 'cashback'];
    @ViewChild(MatSort) sort: MatSort;

    ngOnInit() {
        this.dataSource.sort = this.sort;
        this.dataSource.sortingDataAccessor = (item, headerId) => {
            switch (headerId) {
                case 'period':
                case 'cashback':
                    return item[headerId];
                default:
                    break;
            }
            return '';
        };
    }
}
