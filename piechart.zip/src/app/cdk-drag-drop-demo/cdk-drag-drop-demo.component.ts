import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdk-drag-drop-demo',
  templateUrl: './cdk-drag-drop-demo.component.html',
  styleUrls: ['./cdk-drag-drop-demo.component.css']
})
export class CdkDragDropDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
