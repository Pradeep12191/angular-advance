export class DataContext {
    constructor(
        private $implicit: any = '',
        private backgroundColor: string
    ) {

    }
}
