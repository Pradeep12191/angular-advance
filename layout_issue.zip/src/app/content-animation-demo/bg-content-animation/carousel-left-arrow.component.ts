import { Component } from '@angular/core';


@Component({
    // tslint:disable-next-line:component-selector
    selector: 'carousel-left-arrow',
    template: `<ng-content></ng-content>`
})
export class CarouselLeftArrowComponent {

}
