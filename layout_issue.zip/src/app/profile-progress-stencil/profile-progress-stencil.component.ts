import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-progress-stencil',
  templateUrl: './profile-progress-stencil.component.html',
  styleUrls: ['./profile-progress-stencil.component.css']
})
export class ProfileProgressStencilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
