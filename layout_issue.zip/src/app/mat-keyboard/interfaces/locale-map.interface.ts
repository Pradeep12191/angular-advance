export interface ILocaleMap {
  [locale: string]: string;
}
