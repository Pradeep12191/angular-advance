import { defineCustomElements } from 'dx-accordion/loader';

export default defineCustomElements;

